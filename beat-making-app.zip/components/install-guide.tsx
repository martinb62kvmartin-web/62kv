"use client"

import { Sheet } from "@/components/sheet"

export function InstallGuide({
  open,
  onClose,
}: {
  open: boolean
  onClose: () => void
}) {
  return (
    <Sheet open={open} onClose={onClose} title="УСТАНОВКА НА ANDROID / APK">
      <div className="flex flex-col gap-5 font-mono text-[12px] leading-relaxed text-muted-foreground">
        <section className="flex flex-col gap-2">
          <h3 className="text-sm font-semibold text-foreground">
            Способ 1 — Установить как приложение (PWA)
          </h3>
          <p>Самый быстрый путь, установка прямо с телефона:</p>
          <ol className="ml-4 list-decimal space-y-1">
            <li>Откройте это приложение в Chrome на Android.</li>
            <li>Меню браузера (три точки) → «Установить приложение» / «Добавить на главный экран».</li>
            <li>
              Иконка SP-STUDIO появится на рабочем столе и будет открываться в
              полноэкранном режиме, работая офлайн.
            </li>
          </ol>
        </section>

        <section className="flex flex-col gap-2">
          <h3 className="text-sm font-semibold text-foreground">
            Способ 2 — Собрать настоящий .apk (Capacitor)
          </h3>
          <p>
            Оберните веб-приложение в нативный контейнер. Нужны Node.js и Android
            Studio на компьютере:
          </p>
          <pre className="overflow-x-auto rounded-md border border-border bg-secondary p-3 text-[11px] text-foreground">
{`# 1. В папке проекта
npm i -D @capacitor/cli
npm i @capacitor/core @capacitor/android
npx cap init "SP-STUDIO" com.spstudio.app

# 2. Соберите статику и добавьте Android
npm run build
npx next export   # или настройте output: 'export'
npx cap add android
npx cap copy

# 3. Откройте в Android Studio и соберите APK
npx cap open android
# Build > Build Bundle(s)/APK(s) > Build APK(s)`}
          </pre>
          <p>
            Готовый .apk окажется в{" "}
            <span className="text-foreground">
              android/app/build/outputs/apk/
            </span>
            .
          </p>
        </section>

        <section className="flex flex-col gap-2">
          <h3 className="text-sm font-semibold text-foreground">
            Способ 3 — TWA через Bubblewrap (для Google Play)
          </h3>
          <pre className="overflow-x-auto rounded-md border border-border bg-secondary p-3 text-[11px] text-foreground">
{`npm i -g @bubblewrap/cli
bubblewrap init --manifest https://ВАШ-ДОМЕН/manifest.webmanifest
bubblewrap build`}
          </pre>
          <p>
            Сначала опубликуйте приложение (кнопка Publish в v0), затем укажите
            его URL — Bubblewrap соберёт подписанный APK/AAB.
          </p>
        </section>
      </div>
    </Sheet>
  )
}
