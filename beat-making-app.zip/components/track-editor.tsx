"use client"

import { Play, Repeat, Upload } from "lucide-react"
import { useEffect, useRef, useState } from "react"
import { Knob } from "@/components/knob"
import { Sheet } from "@/components/sheet"
import { Waveform } from "@/components/waveform"
import { Button } from "@/components/ui/button"
import { computePeaks, decodeToBuffer, fileToDataUrl } from "@/lib/peaks"
import type { VoiceType } from "@/lib/types"
import { VOICE_LABELS } from "@/lib/types"
import { cn } from "@/lib/utils"
import type { StudioApi } from "@/hooks/use-studio"

const SYNTH_VOICES: VoiceType[] = [
  "kick",
  "snare",
  "clap",
  "hihat",
  "openhat",
  "tom",
  "rim",
  "cowbell",
]

export function TrackEditor({
  studio,
  trackId,
  onClose,
}: {
  studio: StudioApi
  trackId: string | null
  onClose: () => void
}) {
  const track = studio.pattern.tracks.find((t) => t.id === trackId) ?? null
  const [peaks, setPeaks] = useState<number[]>([])
  const [decoding, setDecoding] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    let cancelled = false
    if (track?.voice === "sample" && track.sampleData) {
      setDecoding(true)
      decodeToBuffer(track.sampleData)
        .then((buf) => !cancelled && setPeaks(computePeaks(buf, 300)))
        .catch((e) => console.log("[v0] waveform decode failed", e))
        .finally(() => !cancelled && setDecoding(false))
    } else {
      setPeaks([])
    }
    return () => {
      cancelled = true
    }
  }, [track?.sampleData, track?.voice])

  if (!track) return null

  const handleUpload = async (file: File) => {
    const dataUrl = await fileToDataUrl(file)
    studio.updateTrack(track.id, {
      voice: "sample",
      sampleData: dataUrl,
      name: file.name.replace(/\.[^.]+$/, "").slice(0, 10).toUpperCase(),
      start: 0,
      end: 1,
      reverse: false,
    })
  }

  return (
    <Sheet open={!!trackId} onClose={onClose} title={`РЕДАКТОР — ${track.name}`}>
      <div className="flex flex-col gap-4">
        {/* name + audition */}
        <div className="flex items-center gap-2">
          <input
            value={track.name}
            onChange={(e) =>
              studio.updateTrack(track.id, { name: e.target.value.slice(0, 14) })
            }
            className="h-9 flex-1 rounded-md border border-input bg-secondary px-3 font-mono text-sm text-foreground outline-none focus-visible:border-ring"
            aria-label="Имя дорожки"
          />
          <Button
            variant="secondary"
            size="lg"
            onClick={() => studio.audition(track)}
          >
            <Play className="size-4" fill="currentColor" />
            Прослушать
          </Button>
        </div>

        {/* sample area */}
        <div className="flex flex-col gap-2">
          {track.voice === "sample" && track.sampleData ? (
            <>
              {decoding ? (
                <div className="flex h-32 items-center justify-center rounded-md border border-border bg-secondary font-mono text-xs text-muted-foreground">
                  Загрузка волны…
                </div>
              ) : (
                <Waveform
                  peaks={peaks}
                  start={track.start}
                  end={track.end}
                  reverse={track.reverse}
                  onChangeStart={(v) => studio.updateTrack(track.id, { start: v })}
                  onChangeEnd={(v) => studio.updateTrack(track.id, { end: v })}
                />
              )}
              <div className="flex gap-2">
                <Button
                  variant={track.reverse ? "default" : "outline"}
                  size="sm"
                  className="flex-1"
                  onClick={() =>
                    studio.updateTrack(track.id, { reverse: !track.reverse })
                  }
                >
                  <Repeat className="size-3.5" />
                  Реверс
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => fileRef.current?.click()}
                >
                  <Upload className="size-3.5" />
                  Заменить
                </Button>
              </div>
            </>
          ) : (
            <button
              onClick={() => fileRef.current?.click()}
              className="flex h-24 flex-col items-center justify-center gap-1 rounded-md border border-dashed border-border bg-secondary text-muted-foreground transition active:translate-y-px"
            >
              <Upload className="size-5" />
              <span className="font-mono text-xs">Загрузить свой сэмпл</span>
              <span className="font-mono text-[10px] opacity-60">
                WAV · MP3 · OGG
              </span>
            </button>
          )}
          <input
            ref={fileRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0]
              if (f) handleUpload(f)
              e.target.value = ""
            }}
          />
        </div>

        {/* voice selector for synth voices */}
        {track.voice !== "sample" && (
          <div className="flex flex-col gap-1.5">
            <span className="font-mono text-[10px] text-muted-foreground">
              ГОЛОС СИНТЕЗА
            </span>
            <div className="grid grid-cols-4 gap-1.5">
              {SYNTH_VOICES.map((v) => (
                <button
                  key={v}
                  onClick={() => studio.updateTrack(track.id, { voice: v })}
                  className={cn(
                    "h-8 rounded-md border font-mono text-[10px] font-semibold transition active:translate-y-px",
                    track.voice === v
                      ? "border-primary/60 bg-primary text-primary-foreground"
                      : "border-border bg-secondary text-muted-foreground",
                  )}
                >
                  {VOICE_LABELS[v]}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* knobs */}
        <div className="flex flex-wrap items-start justify-around gap-3 rounded-md border border-border bg-secondary/40 p-3">
          <Knob
            label="LEVEL"
            value={track.volume}
            min={0}
            max={1}
            onChange={(v) => studio.updateTrack(track.id, { volume: v })}
            format={(v) => `${Math.round(v * 100)}`}
          />
          <Knob
            label="PITCH"
            value={track.pitch}
            min={-24}
            max={24}
            step={1}
            onChange={(v) => studio.updateTrack(track.id, { pitch: v })}
            format={(v) => `${v > 0 ? "+" : ""}${Math.round(v)}`}
            accent="accent"
          />
          <Knob
            label="PAN"
            value={track.pan}
            min={-1}
            max={1}
            onChange={(v) => studio.updateTrack(track.id, { pan: v })}
            format={(v) =>
              v === 0 ? "C" : v < 0 ? `L${Math.round(-v * 100)}` : `R${Math.round(v * 100)}`
            }
          />
          <Knob
            label="DECAY"
            value={track.decay}
            min={0}
            max={1}
            onChange={(v) => studio.updateTrack(track.id, { decay: v })}
            format={(v) => `${Math.round(v * 100)}`}
          />
          {track.voice !== "sample" && (
            <Knob
              label="TONE"
              value={track.tone}
              min={0}
              max={1}
              onChange={(v) => studio.updateTrack(track.id, { tone: v })}
              format={(v) => `${Math.round(v * 100)}`}
              accent="accent"
            />
          )}
        </div>
      </div>
    </Sheet>
  )
}
