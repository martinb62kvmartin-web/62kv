"use client"

import { useCallback, useRef } from "react"

export function Waveform({
  peaks,
  start,
  end,
  onChangeStart,
  onChangeEnd,
  reverse,
}: {
  peaks: number[]
  start: number
  end: number
  onChangeStart: (v: number) => void
  onChangeEnd: (v: number) => void
  reverse?: boolean
}) {
  const containerRef = useRef<HTMLDivElement>(null)
  const dragRef = useRef<"start" | "end" | null>(null)

  const posFromEvent = useCallback((clientX: number) => {
    const el = containerRef.current
    if (!el) return 0
    const rect = el.getBoundingClientRect()
    return Math.max(0, Math.min(1, (clientX - rect.left) / rect.width))
  }, [])

  const onPointerDown = (which: "start" | "end") => (e: React.PointerEvent) => {
    e.preventDefault()
    ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
    dragRef.current = which
  }

  const onPointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current) return
    const p = posFromEvent(e.clientX)
    if (dragRef.current === "start") onChangeStart(Math.min(p, end - 0.01))
    else onChangeEnd(Math.max(p, start + 0.01))
  }

  const onPointerUp = () => {
    dragRef.current = null
  }

  const lo = Math.min(start, end)
  const hi = Math.max(start, end)

  return (
    <div
      ref={containerRef}
      className="relative h-32 w-full touch-none overflow-hidden rounded-md border border-border bg-secondary"
      onPointerMove={onPointerMove}
      onPointerUp={onPointerUp}
    >
      {/* trimmed-out regions */}
      <div
        className="absolute inset-y-0 left-0 bg-background/60"
        style={{ width: `${lo * 100}%` }}
      />
      <div
        className="absolute inset-y-0 right-0 bg-background/60"
        style={{ width: `${(1 - hi) * 100}%` }}
      />

      {/* bars */}
      <div
        className="absolute inset-0 flex items-center gap-px px-px"
        style={{ transform: reverse ? "scaleX(-1)" : undefined }}
      >
        {peaks.map((p, i) => {
          const x = i / peaks.length
          const inRange = x >= lo && x <= hi
          return (
            <span
              key={i}
              className="flex-1 rounded-[1px]"
              style={{
                height: `${Math.max(2, p * 100)}%`,
                backgroundColor: inRange
                  ? "var(--color-primary)"
                  : "var(--color-muted-foreground)",
                opacity: inRange ? 0.9 : 0.35,
              }}
            />
          )
        })}
      </div>

      {/* handles */}
      <Handle pos={lo} onPointerDown={onPointerDown("start")} />
      <Handle pos={hi} onPointerDown={onPointerDown("end")} />
    </div>
  )
}

function Handle({
  pos,
  onPointerDown,
}: {
  pos: number
  onPointerDown: (e: React.PointerEvent) => void
}) {
  return (
    <div
      onPointerDown={onPointerDown}
      className="absolute inset-y-0 z-10 flex w-6 -translate-x-1/2 cursor-ew-resize items-center justify-center"
      style={{ left: `${pos * 100}%` }}
    >
      <span className="h-full w-0.5 bg-accent" />
      <span className="absolute top-1 size-3 rounded-full border border-background bg-accent" />
    </div>
  )
}
