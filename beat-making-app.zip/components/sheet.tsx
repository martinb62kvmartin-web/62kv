"use client"

import { X } from "lucide-react"
import { useEffect } from "react"
import { cn } from "@/lib/utils"

export function Sheet({
  open,
  onClose,
  title,
  children,
  className,
}: {
  open: boolean
  onClose: () => void
  title: string
  children: React.ReactNode
  className?: string
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose()
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [open, onClose])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <button
        aria-label="Закрыть"
        className="absolute inset-0 bg-background/70 backdrop-blur-sm"
        onClick={onClose}
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title}
        className={cn(
          "relative z-10 max-h-[88vh] overflow-y-auto rounded-t-xl border-t border-border bg-card shadow-2xl",
          "animate-in slide-in-from-bottom duration-200",
          className,
        )}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-border bg-card/95 px-4 py-3 backdrop-blur">
          <h2 className="font-mono text-sm font-semibold tracking-tight text-foreground">
            {title}
          </h2>
          <button
            onClick={onClose}
            aria-label="Закрыть"
            className="flex size-8 items-center justify-center rounded-md bg-secondary text-muted-foreground transition active:translate-y-px"
          >
            <X className="size-4" />
          </button>
        </div>
        <div className="p-4">{children}</div>
      </div>
    </div>
  )
}
