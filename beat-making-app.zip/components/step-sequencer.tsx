"use client"

import { SlidersHorizontal } from "lucide-react"
import { cn } from "@/lib/utils"
import { STEP_COUNT } from "@/lib/types"
import type { Track } from "@/lib/types"
import type { StudioApi } from "@/hooks/use-studio"

export function StepSequencer({
  studio,
  onEditTrack,
}: {
  studio: StudioApi
  onEditTrack: (trackId: string) => void
}) {
  const { pattern, currentStep, toggleStep, updateTrack, audition } = studio
  const anySolo = pattern.tracks.some((t) => t.solo)

  return (
    <div className="flex flex-col gap-1.5 p-2">
      {/* step ruler */}
      <div className="flex items-center gap-1 pl-[104px] pr-1">
        {Array.from({ length: STEP_COUNT }).map((_, i) => (
          <div
            key={i}
            className={cn(
              "flex-1 text-center font-mono text-[9px] leading-none",
              i % 4 === 0 ? "text-primary" : "text-muted-foreground/50",
              i % 4 === 0 && i !== 0 && "ml-1",
              currentStep === i && "text-foreground",
            )}
          >
            {i % 4 === 0 ? i / 4 + 1 : ""}
          </div>
        ))}
      </div>

      {pattern.tracks.map((track) => (
        <TrackRow
          key={track.id}
          track={track}
          currentStep={currentStep}
          anySolo={anySolo}
          onToggleStep={(step) => toggleStep(track.id, step)}
          onAudition={() => audition(track)}
          onMute={() => updateTrack(track.id, { muted: !track.muted })}
          onSolo={() => updateTrack(track.id, { solo: !track.solo })}
          onEdit={() => onEditTrack(track.id)}
        />
      ))}
    </div>
  )
}

function TrackRow({
  track,
  currentStep,
  anySolo,
  onToggleStep,
  onAudition,
  onMute,
  onSolo,
  onEdit,
}: {
  track: Track
  currentStep: number
  anySolo: boolean
  onToggleStep: (step: number) => void
  onAudition: () => void
  onMute: () => void
  onSolo: () => void
  onEdit: () => void
}) {
  const dimmed = (anySolo && !track.solo) || track.muted

  return (
    <div className="flex items-center gap-1">
      {/* left control cluster */}
      <div className="flex w-[100px] shrink-0 items-center gap-1">
        <button
          onClick={onAudition}
          onDoubleClick={onEdit}
          className={cn(
            "flex h-9 min-w-0 flex-1 items-center rounded-md border border-border bg-secondary px-2 text-left transition active:translate-y-px",
            dimmed && "opacity-45",
          )}
          aria-label={`Прослушать ${track.name}`}
        >
          <span className="truncate font-mono text-[10px] font-semibold tracking-tight text-foreground">
            {track.name}
          </span>
        </button>
        <div className="flex flex-col gap-0.5">
          <button
            onClick={onMute}
            className={cn(
              "flex h-4 w-5 items-center justify-center rounded-[3px] font-mono text-[8px] font-bold transition",
              track.muted
                ? "bg-destructive text-background"
                : "bg-muted text-muted-foreground",
            )}
            aria-label="Заглушить"
            aria-pressed={track.muted}
          >
            M
          </button>
          <button
            onClick={onSolo}
            className={cn(
              "flex h-4 w-5 items-center justify-center rounded-[3px] font-mono text-[8px] font-bold transition",
              track.solo
                ? "bg-accent text-accent-foreground"
                : "bg-muted text-muted-foreground",
            )}
            aria-label="Соло"
            aria-pressed={track.solo}
          >
            S
          </button>
        </div>
      </div>

      {/* edit button */}
      <button
        onClick={onEdit}
        className="flex size-9 shrink-0 items-center justify-center rounded-md bg-muted text-muted-foreground transition active:translate-y-px"
        aria-label={`Настроить ${track.name}`}
      >
        <SlidersHorizontal className="size-3.5" />
      </button>

      {/* steps */}
      <div className="flex flex-1 items-center gap-1">
        {track.steps.map((vel, i) => {
          const on = vel > 0
          const isBeat = i % 4 === 0
          const playing = currentStep === i
          return (
            <button
              key={i}
              onClick={() => onToggleStep(i)}
              aria-label={`Шаг ${i + 1}`}
              aria-pressed={on}
              className={cn(
                "h-9 flex-1 rounded-[4px] border transition-all",
                isBeat && i !== 0 && "ml-1",
                on
                  ? "border-primary/60 bg-primary shadow-[0_0_8px_-1px_var(--color-primary)]"
                  : isBeat
                    ? "border-border bg-muted"
                    : "border-border/60 bg-secondary",
                playing && "ring-2 ring-accent ring-offset-1 ring-offset-background",
                dimmed && on && "opacity-45",
              )}
              style={on ? { opacity: dimmed ? 0.45 : 0.4 + vel * 0.6 } : undefined}
            />
          )
        })}
      </div>
    </div>
  )
}
