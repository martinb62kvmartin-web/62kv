"use client"

import { Check, FilePlus2, Save, Trash2 } from "lucide-react"
import { useCallback, useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { deletePattern, loadPatterns, savePattern } from "@/lib/db"
import { makeDefaultPattern, uid } from "@/lib/default-kit"
import type { Pattern } from "@/lib/types"
import { cn } from "@/lib/utils"
import type { StudioApi } from "@/hooks/use-studio"

export function PatternLibrary({ studio }: { studio: StudioApi }) {
  const [saved, setSaved] = useState<Pattern[]>([])
  const [justSaved, setJustSaved] = useState(false)

  const refresh = useCallback(async () => {
    try {
      setSaved(await loadPatterns())
    } catch (e) {
      console.log("[v0] load patterns failed", e)
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  const handleSave = async () => {
    await savePattern({ ...studio.pattern, updatedAt: Date.now() })
    setJustSaved(true)
    setTimeout(() => setJustSaved(false), 1500)
    refresh()
  }

  const handleSaveAsNew = async () => {
    const copy: Pattern = {
      ...studio.pattern,
      id: uid(),
      name: `${studio.pattern.name} копия`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
    }
    await savePattern(copy)
    studio.loadPattern(copy)
    refresh()
  }

  const handleNew = () => {
    studio.loadPattern(makeDefaultPattern())
  }

  const handleDelete = async (id: string) => {
    await deletePattern(id)
    refresh()
  }

  return (
    <div className="flex flex-col gap-4 p-3">
      <div className="flex flex-col gap-2 rounded-lg border border-border bg-card p-3">
        <div className="flex items-center gap-2">
          <input
            value={studio.pattern.name}
            onChange={(e) => studio.renamePattern(e.target.value.slice(0, 28))}
            className="h-9 flex-1 rounded-md border border-input bg-secondary px-3 font-mono text-sm text-foreground outline-none focus-visible:border-ring"
            aria-label="Название текущего паттерна"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <Button size="lg" className="flex-1" onClick={handleSave}>
            {justSaved ? <Check className="size-4" /> : <Save className="size-4" />}
            {justSaved ? "Сохранено" : "Сохранить"}
          </Button>
          <Button variant="secondary" size="lg" onClick={handleSaveAsNew}>
            Как новый
          </Button>
          <Button variant="outline" size="lg" onClick={handleNew}>
            <FilePlus2 className="size-4" />
            Новый
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <span className="px-1 font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
          Сохранённые биты · {saved.length}
        </span>
        {saved.length === 0 && (
          <p className="rounded-md border border-dashed border-border bg-secondary/40 p-4 text-center font-mono text-xs text-muted-foreground">
            Пока нет сохранённых паттернов. Нажмите «Сохранить».
          </p>
        )}
        {saved.map((p) => {
          const isCurrent = p.id === studio.pattern.id
          return (
            <div
              key={p.id}
              className={cn(
                "flex items-center gap-2 rounded-md border bg-card p-2",
                isCurrent ? "border-primary/50" : "border-border",
              )}
            >
              <button
                onClick={() => studio.loadPattern(p)}
                className="flex min-w-0 flex-1 flex-col items-start text-left"
              >
                <span className="truncate font-mono text-sm text-foreground">
                  {p.name}
                </span>
                <span className="font-mono text-[10px] text-muted-foreground">
                  {p.bpm} BPM · {p.bitDepth}-bit ·{" "}
                  {p.tracks.reduce(
                    (n, t) => n + t.steps.filter((s) => s > 0).length,
                    0,
                  )}{" "}
                  нот
                </span>
              </button>
              {isCurrent && (
                <span className="rounded-sm bg-primary/15 px-1.5 py-0.5 font-mono text-[9px] text-primary">
                  ТЕКУЩИЙ
                </span>
              )}
              <Button
                variant="ghost"
                size="icon"
                aria-label="Удалить"
                onClick={() => handleDelete(p.id)}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          )
        })}
      </div>
    </div>
  )
}
