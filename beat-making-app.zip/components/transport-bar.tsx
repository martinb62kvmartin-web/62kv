"use client"

import { Pause, Play, Square, Trash2 } from "lucide-react"
import { Knob } from "@/components/knob"
import { LevelMeter } from "@/components/level-meter"
import { Button } from "@/components/ui/button"
import type { StudioApi } from "@/hooks/use-studio"

export function TransportBar({ studio }: { studio: StudioApi }) {
  const { pattern, isPlaying, toggle, stop, clearSteps } = studio

  return (
    <header className="sticky top-0 z-30 border-b border-border bg-card/95 backdrop-blur supports-[backdrop-filter]:bg-card/80">
      <div className="flex items-center gap-3 px-3 py-2">
        <div className="flex items-center gap-1.5">
          <button
            onClick={toggle}
            aria-label={isPlaying ? "Пауза" : "Играть"}
            className="flex size-11 items-center justify-center rounded-md bg-primary text-primary-foreground shadow-sm transition active:translate-y-px"
          >
            {isPlaying ? (
              <Pause className="size-5" fill="currentColor" />
            ) : (
              <Play className="size-5" fill="currentColor" />
            )}
          </button>
          <button
            onClick={stop}
            aria-label="Стоп"
            className="flex size-11 items-center justify-center rounded-md bg-secondary text-secondary-foreground transition active:translate-y-px"
          >
            <Square className="size-4" fill="currentColor" />
          </button>
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2">
            <span className="truncate font-mono text-sm font-semibold text-foreground">
              {pattern.name}
            </span>
          </div>
          <div className="mt-0.5 flex items-center gap-3 font-mono text-[10px] text-muted-foreground">
            <span>
              <span className="text-primary">{pattern.bpm}</span> BPM
            </span>
            <span>{pattern.bitDepth}-BIT</span>
            <span>SWING {Math.round(pattern.swing * 100)}%</span>
          </div>
        </div>

        <div className="hidden sm:block">
          <LevelMeter engineRef={studio.engineRef} active={isPlaying} />
        </div>

        <Button
          variant="ghost"
          size="icon"
          aria-label="Очистить шаги"
          onClick={clearSteps}
        >
          <Trash2 className="size-4" />
        </Button>
      </div>

      <div className="flex items-center justify-around gap-2 border-t border-border/60 px-3 py-2">
        <Knob
          label="TEMPO"
          value={pattern.bpm}
          min={40}
          max={200}
          step={1}
          format={(v) => `${Math.round(v)}`}
          onChange={studio.setBpm}
        />
        <Knob
          label="SWING"
          value={pattern.swing}
          min={0}
          max={0.75}
          step={0.01}
          format={(v) => `${Math.round(v * 100)}%`}
          onChange={studio.setSwing}
          accent="accent"
        />
        <Knob
          label="BIT"
          value={pattern.bitDepth}
          min={4}
          max={16}
          step={1}
          format={(v) => `${Math.round(v)}`}
          onChange={studio.setBitDepth}
          accent="destructive"
        />
        <div className="sm:hidden">
          <LevelMeter engineRef={studio.engineRef} active={isPlaying} />
        </div>
      </div>
    </header>
  )
}
