"use client"

import { Download, Info, Loader2, Plus, Upload, Waves } from "lucide-react"
import { useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import { decodeToBuffer, fileToDataUrl } from "@/lib/peaks"
import { decodeFileToBuffer, splitIntoBands, type StemResult } from "@/lib/stems"
import { audioBufferToWav, downloadBlob } from "@/lib/wav"
import { makeTrack } from "@/lib/default-kit"
import type { StudioApi } from "@/hooks/use-studio"

export function StemSplitter({ studio }: { studio: StudioApi }) {
  const [fileName, setFileName] = useState<string | null>(null)
  const [stems, setStems] = useState<StemResult[]>([])
  const [progress, setProgress] = useState(0)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileRef = useRef<HTMLInputElement>(null)
  const ctxRef = useRef<AudioContext | null>(null)

  const handleFile = async (file: File) => {
    setError(null)
    setStems([])
    setFileName(file.name)
    setBusy(true)
    setProgress(0)
    try {
      if (!ctxRef.current) ctxRef.current = new AudioContext()
      const buffer = await decodeFileToBuffer(ctxRef.current, file)
      const result = await splitIntoBands(buffer, (d, t) =>
        setProgress(Math.round((d / t) * 100)),
      )
      setStems(result)
    } catch (e) {
      console.log("[v0] stem split failed", e)
      setError("Не удалось обработать файл. Попробуйте WAV или MP3.")
    } finally {
      setBusy(false)
    }
  }

  const downloadStem = (stem: StemResult) => {
    const base = (fileName ?? "track").replace(/\.[^.]+$/, "")
    const tag = stem.name.replace(/[^\p{L}\p{N}]+/gu, "_")
    downloadBlob(audioBufferToWav(stem.buffer), `${base}_${tag}.wav`)
  }

  const addStemToKit = async (stem: StemResult) => {
    const dataUrl = URL.createObjectURL(audioBufferToWav(stem.buffer))
    // convert blob url to data url for persistence
    const blob = await fetch(dataUrl).then((r) => r.blob())
    const reader = new FileReader()
    reader.onload = () => {
      const track = makeTrack("sample", stem.name.slice(0, 10).toUpperCase())
      track.sampleData = reader.result as string
      track.steps[0] = 1
      studio.commit({
        ...studio.pattern,
        tracks: [...studio.pattern.tracks, track],
      })
      URL.revokeObjectURL(dataUrl)
    }
    reader.readAsDataURL(blob)
  }

  return (
    <div className="flex flex-col gap-4 p-3">
      <div className="flex items-start gap-2 rounded-lg border border-accent/30 bg-accent/5 p-3">
        <Info className="mt-0.5 size-4 shrink-0 text-accent" />
        <p className="font-mono text-[11px] leading-relaxed text-muted-foreground">
          Разделение работает <span className="text-foreground">на устройстве</span>{" "}
          по частотным полосам (низ/бас, тело, презенс, перкуссия). Полноценное
          ML-разделение на вокал/барабаны/бас (Demucs) требует внешнего
          аудио-сервиса — модуль{" "}
          <span className="text-foreground">separateWithAI</span> готов для
          подключения такого API.
        </p>
      </div>

      <button
        onClick={() => fileRef.current?.click()}
        disabled={busy}
        className="flex h-28 flex-col items-center justify-center gap-1.5 rounded-lg border border-dashed border-border bg-card text-muted-foreground transition active:translate-y-px disabled:opacity-60"
      >
        {busy ? (
          <>
            <Loader2 className="size-6 animate-spin text-primary" />
            <span className="font-mono text-xs">Обработка… {progress}%</span>
          </>
        ) : (
          <>
            <Upload className="size-6" />
            <span className="font-mono text-xs">Загрузить трек для разбивки</span>
            <span className="font-mono text-[10px] opacity-60">WAV · MP3 · OGG</span>
          </>
        )}
      </button>
      <input
        ref={fileRef}
        type="file"
        accept="audio/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0]
          if (f) handleFile(f)
          e.target.value = ""
        }}
      />

      {fileName && !busy && (
        <div className="flex items-center gap-2 px-1 font-mono text-[11px] text-muted-foreground">
          <Waves className="size-3.5 text-primary" />
          <span className="truncate">{fileName}</span>
        </div>
      )}

      {error && (
        <p className="rounded-md border border-destructive/40 bg-destructive/10 p-3 font-mono text-xs text-destructive">
          {error}
        </p>
      )}

      {stems.length > 0 && (
        <div className="flex flex-col gap-2">
          {stems.map((stem) => (
            <div
              key={stem.name}
              className="flex flex-col gap-2 rounded-lg border border-border bg-card p-3"
            >
              <div>
                <span className="font-mono text-sm text-foreground">
                  {stem.name}
                </span>
                <p className="font-mono text-[10px] text-muted-foreground">
                  {stem.description}
                </p>
              </div>
              <div className="flex gap-2">
                <Button
                  variant="secondary"
                  size="sm"
                  className="flex-1"
                  onClick={() => downloadStem(stem)}
                >
                  <Download className="size-3.5" />
                  WAV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="flex-1"
                  onClick={() => addStemToKit(stem)}
                >
                  <Plus className="size-3.5" />
                  В набор
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
