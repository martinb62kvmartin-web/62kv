"use client"

import { useCallback, useRef } from "react"
import { cn } from "@/lib/utils"

interface KnobProps {
  label: string
  value: number
  min: number
  max: number
  step?: number
  /** formatting for the readout */
  format?: (v: number) => string
  onChange: (v: number) => void
  className?: string
  accent?: "primary" | "accent" | "destructive"
}

export function Knob({
  label,
  value,
  min,
  max,
  step = 0.01,
  format,
  onChange,
  className,
  accent = "primary",
}: KnobProps) {
  const startRef = useRef<{ y: number; val: number } | null>(null)

  const norm = (value - min) / (max - min)
  const angle = -135 + norm * 270

  const clamp = (v: number) => Math.max(min, Math.min(max, v))
  const quant = (v: number) => Math.round(v / step) * step

  const onPointerDown = useCallback(
    (e: React.PointerEvent) => {
      e.preventDefault()
      ;(e.target as HTMLElement).setPointerCapture(e.pointerId)
      startRef.current = { y: e.clientY, val: value }
    },
    [value],
  )

  const onPointerMove = useCallback(
    (e: React.PointerEvent) => {
      if (!startRef.current) return
      const dy = startRef.current.y - e.clientY
      const range = max - min
      const delta = (dy / 150) * range
      onChange(clamp(quant(startRef.current.val + delta)))
    },
    [max, min, onChange],
  )

  const onPointerUp = useCallback((e: React.PointerEvent) => {
    startRef.current = null
    try {
      ;(e.target as HTMLElement).releasePointerCapture(e.pointerId)
    } catch {}
  }, [])

  const onDoubleClick = useCallback(() => {
    onChange(clamp(quant((min + max) / 2)))
  }, [min, max, onChange])

  const accentColor =
    accent === "accent"
      ? "var(--color-accent)"
      : accent === "destructive"
        ? "var(--color-destructive)"
        : "var(--color-primary)"

  return (
    <div className={cn("flex flex-col items-center gap-1 select-none", className)}>
      <div
        role="slider"
        aria-label={label}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={value}
        tabIndex={0}
        className="relative size-11 cursor-ns-resize touch-none rounded-full border border-border bg-secondary shadow-inner"
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onDoubleClick={onDoubleClick}
        onKeyDown={(e) => {
          if (e.key === "ArrowUp" || e.key === "ArrowRight")
            onChange(clamp(quant(value + step)))
          if (e.key === "ArrowDown" || e.key === "ArrowLeft")
            onChange(clamp(quant(value - step)))
        }}
      >
        {/* indicator dial */}
        <div
          className="absolute inset-0 flex items-start justify-center"
          style={{ transform: `rotate(${angle}deg)` }}
        >
          <span
            className="mt-1 h-3 w-0.5 rounded-full"
            style={{ backgroundColor: accentColor }}
          />
        </div>
        <span
          className="absolute inset-2 rounded-full"
          style={{
            background:
              "radial-gradient(circle at 50% 35%, oklch(0.32 0.006 60), oklch(0.19 0.005 60))",
          }}
        />
      </div>
      <span className="font-mono text-[10px] leading-none text-muted-foreground">
        {label}
      </span>
      <span className="font-mono text-[10px] leading-none text-foreground">
        {format ? format(value) : value.toFixed(2)}
      </span>
    </div>
  )
}
