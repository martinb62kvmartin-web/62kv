"use client"

import { useEffect, useRef } from "react"
import type { AudioEngine } from "@/lib/audio-engine"

export function LevelMeter({
  engineRef,
  active,
}: {
  engineRef: React.RefObject<AudioEngine | null>
  active: boolean
}) {
  const barsRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let raf = 0
    const data = new Uint8Array(128)
    const render = () => {
      const analyser = engineRef.current?.getAnalyser()
      const bars = barsRef.current
      if (analyser && bars) {
        analyser.getByteFrequencyData(data)
        const children = bars.children
        const n = children.length
        for (let i = 0; i < n; i++) {
          const idx = Math.floor((i / n) * 48)
          const v = data[idx] / 255
          const el = children[i] as HTMLElement
          el.style.transform = `scaleY(${Math.max(0.06, v)})`
          el.style.opacity = `${0.35 + v * 0.65}`
        }
      }
      raf = requestAnimationFrame(render)
    }
    raf = requestAnimationFrame(render)
    return () => cancelAnimationFrame(raf)
  }, [engineRef])

  return (
    <div
      ref={barsRef}
      className="flex h-8 items-end gap-0.5"
      aria-hidden="true"
    >
      {Array.from({ length: 20 }).map((_, i) => (
        <span
          key={i}
          className="h-full w-1 origin-bottom rounded-sm bg-primary transition-none"
          style={{ transform: "scaleY(0.06)" }}
        />
      ))}
    </div>
  )
}
