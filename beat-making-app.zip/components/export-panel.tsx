"use client"

import { Download, Loader2, Music4 } from "lucide-react"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { audioBufferToWav, downloadBlob, renderPattern } from "@/lib/wav"
import { cn } from "@/lib/utils"
import type { StudioApi } from "@/hooks/use-studio"

const BAR_OPTIONS = [1, 2, 4, 8]

export function ExportPanel({ studio }: { studio: StudioApi }) {
  const [bars, setBars] = useState(2)
  const [busy, setBusy] = useState<string | null>(null)

  const safeName = studio.pattern.name.replace(/[^\p{L}\p{N}_-]+/gu, "_")

  const exportMix = async () => {
    setBusy("mix")
    try {
      const buf = await renderPattern(studio.pattern, { bars })
      downloadBlob(audioBufferToWav(buf), `${safeName}_${bars}bar.wav`)
    } catch (e) {
      console.log("[v0] export mix failed", e)
    } finally {
      setBusy(null)
    }
  }

  const exportStems = async () => {
    setBusy("stems")
    try {
      for (const track of studio.pattern.tracks) {
        const hasNotes = track.steps.some((s) => s > 0)
        if (!hasNotes) continue
        const buf = await renderPattern(
          studio.pattern,
          { bars },
          (t) => t.id === track.id,
        )
        const tn = track.name.replace(/[^\p{L}\p{N}_-]+/gu, "_")
        downloadBlob(audioBufferToWav(buf), `${safeName}_${tn}.wav`)
        // small delay so the browser doesn't block multiple downloads
        await new Promise((r) => setTimeout(r, 400))
      }
    } catch (e) {
      console.log("[v0] export stems failed", e)
    } finally {
      setBusy(null)
    }
  }

  return (
    <div className="flex flex-col gap-4 p-3">
      <div className="rounded-lg border border-border bg-card p-3">
        <span className="font-mono text-[10px] uppercase tracking-wide text-muted-foreground">
          Длина рендера
        </span>
        <div className="mt-2 grid grid-cols-4 gap-1.5">
          {BAR_OPTIONS.map((b) => (
            <button
              key={b}
              onClick={() => setBars(b)}
              className={cn(
                "h-10 rounded-md border font-mono text-sm font-semibold transition active:translate-y-px",
                bars === b
                  ? "border-primary/60 bg-primary text-primary-foreground"
                  : "border-border bg-secondary text-muted-foreground",
              )}
            >
              {b} {b === 1 ? "такт" : "такта"}
            </button>
          ))}
        </div>
      </div>

      <div className="flex flex-col gap-2 rounded-lg border border-border bg-card p-3">
        <div className="flex items-center gap-2">
          <Music4 className="size-4 text-primary" />
          <span className="font-mono text-sm text-foreground">Полный микс</span>
        </div>
        <p className="font-mono text-[11px] leading-relaxed text-muted-foreground">
          Рендер всего бита в один WAV-файл (44.1 кГц, 16-бит) с применённым
          {" "}{studio.pattern.bitDepth}-битным грувом SP-1200.
        </p>
        <Button size="lg" onClick={exportMix} disabled={busy !== null}>
          {busy === "mix" ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Download className="size-4" />
          )}
          Экспорт микса (WAV)
        </Button>
      </div>

      <div className="flex flex-col gap-2 rounded-lg border border-border bg-card p-3">
        <div className="flex items-center gap-2">
          <Music4 className="size-4 text-accent" />
          <span className="font-mono text-sm text-foreground">
            Стемы по дорожкам
          </span>
        </div>
        <p className="font-mono text-[11px] leading-relaxed text-muted-foreground">
          Каждая дорожка с нотами выгружается отдельным WAV-файлом для сведения
          в вашей DAW. Разрешите множественную загрузку в браузере.
        </p>
        <Button
          variant="secondary"
          size="lg"
          onClick={exportStems}
          disabled={busy !== null}
        >
          {busy === "stems" ? (
            <Loader2 className="size-4 animate-spin" />
          ) : (
            <Download className="size-4" />
          )}
          Экспорт стемов дорожек
        </Button>
      </div>
    </div>
  )
}
