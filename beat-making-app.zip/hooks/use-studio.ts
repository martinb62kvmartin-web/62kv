"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { AudioEngine } from "@/lib/audio-engine"
import { makeDefaultPattern } from "@/lib/default-kit"
import type { Pattern, Track } from "@/lib/types"

export function useStudio() {
  const engineRef = useRef<AudioEngine | null>(null)
  const [pattern, setPatternState] = useState<Pattern>(() =>
    makeDefaultPattern(),
  )
  const [isPlaying, setIsPlaying] = useState(false)
  const [currentStep, setCurrentStep] = useState(-1)
  const [ready, setReady] = useState(false)

  // Keep a ref of the latest pattern so the engine always plays current state
  const patternRef = useRef(pattern)
  patternRef.current = pattern

  useEffect(() => {
    const engine = new AudioEngine()
    engine.onStep = (s) => setCurrentStep(s)
    engineRef.current = engine
    return () => engine.stop()
  }, [])

  // Sync pattern into engine whenever it changes
  useEffect(() => {
    const engine = engineRef.current
    if (!engine || !engine.ctx) return
    engine.setPattern(pattern)
  }, [pattern])

  const commit = useCallback((next: Pattern) => {
    next.updatedAt = Date.now()
    setPatternState(next)
  }, [])

  const play = useCallback(async () => {
    const engine = engineRef.current
    if (!engine) return
    await engine.ensureContext()
    await engine.setPattern(patternRef.current)
    setReady(true)
    await engine.play()
    setIsPlaying(true)
  }, [])

  const stop = useCallback(() => {
    engineRef.current?.stop()
    setIsPlaying(false)
    setCurrentStep(-1)
  }, [])

  const toggle = useCallback(() => {
    if (isPlaying) stop()
    else play()
  }, [isPlaying, play, stop])

  const toggleStep = useCallback(
    (trackId: string, step: number, velocity = 1) => {
      commit({
        ...patternRef.current,
        tracks: patternRef.current.tracks.map((t) =>
          t.id === trackId
            ? {
                ...t,
                steps: t.steps.map((v, i) =>
                  i === step ? (v ? 0 : velocity) : v,
                ),
              }
            : t,
        ),
      })
    },
    [commit],
  )

  const setStepVelocity = useCallback(
    (trackId: string, step: number, velocity: number) => {
      commit({
        ...patternRef.current,
        tracks: patternRef.current.tracks.map((t) =>
          t.id === trackId
            ? { ...t, steps: t.steps.map((v, i) => (i === step ? velocity : v)) }
            : t,
        ),
      })
    },
    [commit],
  )

  const updateTrack = useCallback(
    (trackId: string, patch: Partial<Track>) => {
      const next = {
        ...patternRef.current,
        tracks: patternRef.current.tracks.map((t) =>
          t.id === trackId ? { ...t, ...patch } : t,
        ),
      }
      commit(next)
      // if sample-related fields changed, refresh decode
      const engine = engineRef.current
      const track = next.tracks.find((t) => t.id === trackId)
      if (engine && track && (patch.sampleData !== undefined || patch.reverse !== undefined)) {
        if (patch.sampleData !== undefined && track.sampleData) {
          engine.invalidateSample(track.sampleData)
        }
        engine.refreshTrackSample(track)
      }
    },
    [commit],
  )

  const audition = useCallback((track: Track) => {
    engineRef.current?.audition(track)
  }, [])

  const setBpm = useCallback(
    (bpm: number) => commit({ ...patternRef.current, bpm }),
    [commit],
  )
  const setSwing = useCallback(
    (swing: number) => commit({ ...patternRef.current, swing }),
    [commit],
  )
  const setBitDepth = useCallback(
    (bitDepth: number) => {
      engineRef.current?.setBitDepth(bitDepth)
      commit({ ...patternRef.current, bitDepth })
    },
    [commit],
  )

  const clearSteps = useCallback(() => {
    commit({
      ...patternRef.current,
      tracks: patternRef.current.tracks.map((t) => ({
        ...t,
        steps: t.steps.map(() => 0),
      })),
    })
  }, [commit])

  const loadPattern = useCallback(
    (p: Pattern) => {
      stop()
      setPatternState(p)
    },
    [stop],
  )

  const renamePattern = useCallback(
    (name: string) => commit({ ...patternRef.current, name }),
    [commit],
  )

  return {
    engineRef,
    pattern,
    isPlaying,
    currentStep,
    ready,
    play,
    stop,
    toggle,
    toggleStep,
    setStepVelocity,
    updateTrack,
    audition,
    setBpm,
    setSwing,
    setBitDepth,
    clearSteps,
    loadPattern,
    renamePattern,
    commit,
  }
}

export type StudioApi = ReturnType<typeof useStudio>
