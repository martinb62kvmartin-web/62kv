export function computePeaks(buffer: AudioBuffer, buckets = 400): number[] {
  const data = buffer.getChannelData(0)
  const blockSize = Math.floor(data.length / buckets) || 1
  const peaks: number[] = []
  for (let i = 0; i < buckets; i++) {
    let max = 0
    const start = i * blockSize
    for (let j = 0; j < blockSize; j++) {
      const v = Math.abs(data[start + j] || 0)
      if (v > max) max = v
    }
    peaks.push(max)
  }
  // normalize
  const peak = Math.max(...peaks, 0.0001)
  return peaks.map((p) => p / peak)
}

let decodeCtx: AudioContext | null = null
function getDecodeCtx() {
  if (!decodeCtx) decodeCtx = new AudioContext()
  return decodeCtx
}

export async function decodeToBuffer(dataUrl: string): Promise<AudioBuffer> {
  const ctx = getDecodeCtx()
  const res = await fetch(dataUrl)
  const arr = await res.arrayBuffer()
  return ctx.decodeAudioData(arr)
}

export function fileToDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result as string)
    reader.onerror = () => reject(reader.error)
    reader.readAsDataURL(file)
  })
}
