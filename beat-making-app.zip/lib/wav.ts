import type { Pattern, Track } from "./types"
import { STEP_COUNT } from "./types"
import {
  decodeSample,
  makeBitcrushCurve,
  reverseBuffer,
  triggerVoice,
} from "./audio-engine"

/** Encode an AudioBuffer to a 16-bit PCM WAV Blob. */
export function audioBufferToWav(buffer: AudioBuffer): Blob {
  const numCh = buffer.numberOfChannels
  const sampleRate = buffer.sampleRate
  const numFrames = buffer.length
  const bytesPerSample = 2
  const blockAlign = numCh * bytesPerSample
  const dataSize = numFrames * blockAlign
  const bufferSize = 44 + dataSize
  const arr = new ArrayBuffer(bufferSize)
  const view = new DataView(arr)

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i))
  }

  writeStr(0, "RIFF")
  view.setUint32(4, 36 + dataSize, true)
  writeStr(8, "WAVE")
  writeStr(12, "fmt ")
  view.setUint32(16, 16, true)
  view.setUint16(20, 1, true) // PCM
  view.setUint16(22, numCh, true)
  view.setUint32(24, sampleRate, true)
  view.setUint32(28, sampleRate * blockAlign, true)
  view.setUint16(32, blockAlign, true)
  view.setUint16(34, 16, true)
  writeStr(36, "data")
  view.setUint32(40, dataSize, true)

  const channels: Float32Array[] = []
  for (let c = 0; c < numCh; c++) channels.push(buffer.getChannelData(c))

  let offset = 44
  for (let i = 0; i < numFrames; i++) {
    for (let c = 0; c < numCh; c++) {
      let sample = Math.max(-1, Math.min(1, channels[c][i]))
      sample = sample < 0 ? sample * 0x8000 : sample * 0x7fff
      view.setInt16(offset, sample, true)
      offset += 2
    }
  }
  return new Blob([arr], { type: "audio/wav" })
}

interface RenderOptions {
  bars?: number
  tail?: number
}

/**
 * Renders a pattern offline into an AudioBuffer. Optionally limit to a subset
 * of tracks (used for exporting individual stems).
 */
export async function renderPattern(
  pattern: Pattern,
  opts: RenderOptions = {},
  trackFilter?: (t: Track) => boolean,
): Promise<AudioBuffer> {
  const bars = opts.bars ?? 2
  const tail = opts.tail ?? 1.0
  const sampleRate = 44100
  const secPerBeat = 60 / pattern.bpm
  const secPerStep = secPerBeat / 4
  const totalSteps = STEP_COUNT * bars
  const duration = totalSteps * secPerStep + tail

  const offline = new OfflineAudioContext(
    2,
    Math.ceil(duration * sampleRate),
    sampleRate,
  )

  const master = offline.createGain()
  master.gain.value = 0.9
  const crusher = offline.createWaveShaper()
  crusher.curve = makeBitcrushCurve(pattern.bitDepth)
  crusher.oversample = "none"
  master.connect(crusher)
  crusher.connect(offline.destination)

  const tracks = trackFilter
    ? pattern.tracks.filter(trackFilter)
    : pattern.tracks
  const anySolo = pattern.tracks.some((t) => t.solo)

  // Decode all needed samples
  const decoded = new Map<string, AudioBuffer>()
  for (const t of tracks) {
    if (t.voice === "sample" && t.sampleData) {
      try {
        let buf = await decodeSample(offline, t.sampleData)
        if (t.reverse) buf = reverseBuffer(offline, buf)
        decoded.set(t.sampleData + (t.reverse ? "#r" : ""), buf)
      } catch (e) {
        console.log("[v0] export decode failed", e)
      }
    }
  }

  for (let bar = 0; bar < bars; bar++) {
    for (let step = 0; step < STEP_COUNT; step++) {
      const isOffbeat = step % 2 === 1
      const swingDelay = isOffbeat ? secPerStep * 0.5 * pattern.swing : 0
      const time = (bar * STEP_COUNT + step) * secPerStep + swingDelay + 0.02
      for (const track of tracks) {
        const vel = track.steps[step]
        if (!vel || track.muted) continue
        if (anySolo && !track.solo) continue
        let sampleBuffer: AudioBuffer | undefined
        if (track.voice === "sample" && track.sampleData) {
          sampleBuffer = decoded.get(
            track.sampleData + (track.reverse ? "#r" : ""),
          )
        }
        triggerVoice({
          ctx: offline,
          dest: master,
          track,
          time,
          velocity: vel,
          sampleBuffer,
        })
      }
    }
  }

  return offline.startRendering()
}

export function downloadBlob(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  setTimeout(() => URL.revokeObjectURL(url), 2000)
}
