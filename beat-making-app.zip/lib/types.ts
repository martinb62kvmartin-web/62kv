export type VoiceType =
  | "kick"
  | "snare"
  | "clap"
  | "hihat"
  | "openhat"
  | "tom"
  | "rim"
  | "cowbell"
  | "sample"

export interface Track {
  id: string
  name: string
  voice: VoiceType
  /** Base64-encoded WAV/audio data URL for user or AI samples. Null for synth voices. */
  sampleData: string | null
  /** Sample edit params */
  start: number // 0..1 normalized start point
  end: number // 0..1 normalized end point
  reverse: boolean
  /** Playback / mix params */
  volume: number // 0..1
  pan: number // -1..1
  pitch: number // semitones, -24..24
  decay: number // 0..1 amount of amplitude decay
  tone: number // 0..1 timbre control (per synth voice)
  muted: boolean
  solo: boolean
  /** step booleans (with velocity) */
  steps: number[] // length = STEP_COUNT, 0 = off, 0..1 = velocity
}

export interface Pattern {
  id: string
  name: string
  bpm: number
  swing: number // 0..1
  bitDepth: number // 8..16, SP1200 = 12
  tracks: Track[]
  updatedAt: number
  createdAt: number
}

export const STEP_COUNT = 16

export const VOICE_LABELS: Record<VoiceType, string> = {
  kick: "KICK",
  snare: "SNARE",
  clap: "CLAP",
  hihat: "HAT",
  openhat: "OPEN",
  tom: "TOM",
  rim: "RIM",
  cowbell: "COW",
  sample: "SMPL",
}
