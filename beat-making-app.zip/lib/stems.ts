/**
 * DSP-based stem splitter.
 *
 * NOTE: True source separation (isolating vocals / drums / bass as separate
 * instruments) requires a machine-learning model such as Demucs or Spleeter,
 * which runs on a dedicated audio inference server. That is intentionally left
 * as a pluggable server call (see `separateWithAI`). This local splitter does
 * an honest *frequency-band* separation entirely on-device, which is fast,
 * offline, and useful for isolating low-end, body, and high percussion.
 */

export interface StemResult {
  name: string
  description: string
  buffer: AudioBuffer
}

interface BandDef {
  name: string
  description: string
  type: BiquadFilterType
  freq: number
  q?: number
  type2?: BiquadFilterType
  freq2?: number
}

const BANDS: BandDef[] = [
  {
    name: "Low / Bass",
    description: "Суб-бас, бочка и низкие частоты (< 200 Гц)",
    type: "lowpass",
    freq: 200,
    q: 0.7,
  },
  {
    name: "Low-Mid / Body",
    description: "Тело микса, малый барабан, низкая гармоника (200–1200 Гц)",
    type: "highpass",
    freq: 200,
    type2: "lowpass",
    freq2: 1200,
  },
  {
    name: "High-Mid / Presence",
    description: "Вокал, инструментальная атака (1.2–5 кГц)",
    type: "highpass",
    freq: 1200,
    type2: "lowpass",
    freq2: 5000,
  },
  {
    name: "High / Percussion",
    description: "Хэты, шейкеры, воздух (> 5 кГц)",
    type: "highpass",
    freq: 5000,
    q: 0.7,
  },
]

async function renderBand(
  source: AudioBuffer,
  band: BandDef,
): Promise<AudioBuffer> {
  const offline = new OfflineAudioContext(
    source.numberOfChannels,
    source.length,
    source.sampleRate,
  )
  const src = offline.createBufferSource()
  src.buffer = source

  const f1 = offline.createBiquadFilter()
  f1.type = band.type
  f1.frequency.value = band.freq
  if (band.q) f1.Q.value = band.q

  src.connect(f1)

  if (band.type2 && band.freq2) {
    const f2 = offline.createBiquadFilter()
    f2.type = band.type2
    f2.frequency.value = band.freq2
    f1.connect(f2)
    f2.connect(offline.destination)
  } else {
    f1.connect(offline.destination)
  }

  src.start(0)
  return offline.startRendering()
}

export async function splitIntoBands(
  source: AudioBuffer,
  onProgress?: (done: number, total: number) => void,
): Promise<StemResult[]> {
  const results: StemResult[] = []
  for (let i = 0; i < BANDS.length; i++) {
    const band = BANDS[i]
    const buffer = await renderBand(source, band)
    results.push({ name: band.name, description: band.description, buffer })
    onProgress?.(i + 1, BANDS.length)
  }
  return results
}

export async function decodeFileToBuffer(
  ctx: BaseAudioContext,
  file: File,
): Promise<AudioBuffer> {
  const arr = await file.arrayBuffer()
  return ctx.decodeAudioData(arr)
}

/**
 * Placeholder for real ML source separation via an external inference API.
 * Wire this up to a Demucs/Spleeter endpoint when available.
 */
export async function separateWithAI(): Promise<never> {
  throw new Error(
    "ML-разделение (вокал/барабаны/бас) требует внешнего аудио-сервиса (Demucs/Spleeter). Пока доступно частотное разделение на устройстве.",
  )
}
