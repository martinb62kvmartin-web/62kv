import type { Pattern, Track, VoiceType } from "./types"
import { STEP_COUNT } from "./types"

export function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36)
}

function emptySteps(): number[] {
  return new Array(STEP_COUNT).fill(0)
}

export function makeTrack(voice: VoiceType, name: string): Track {
  return {
    id: uid(),
    name,
    voice,
    sampleData: null,
    start: 0,
    end: 1,
    reverse: false,
    volume: 0.85,
    pan: 0,
    pitch: 0,
    decay: 0.5,
    tone: 0.5,
    muted: false,
    solo: false,
    steps: emptySteps(),
  }
}

export function makeDefaultPattern(): Pattern {
  const kick = makeTrack("kick", "KICK")
  const snare = makeTrack("snare", "SNARE")
  const hat = makeTrack("hihat", "HAT")
  const openhat = makeTrack("openhat", "OPEN HAT")
  const clap = makeTrack("clap", "CLAP")
  const rim = makeTrack("rim", "RIM")
  const cowbell = makeTrack("cowbell", "COWBELL")
  const tom = makeTrack("tom", "TOM")

  // A classic boom-bap-ish starter groove
  kick.steps[0] = 1
  kick.steps[6] = 0.8
  kick.steps[8] = 1
  kick.steps[10] = 0.7

  snare.steps[4] = 1
  snare.steps[12] = 1

  hat.steps[0] = 0.6
  hat.steps[2] = 0.5
  hat.steps[4] = 0.6
  hat.steps[6] = 0.5
  hat.steps[8] = 0.6
  hat.steps[10] = 0.5
  hat.steps[12] = 0.6
  hat.steps[14] = 0.5

  openhat.steps[14] = 0.7

  return {
    id: uid(),
    name: "Новый бит",
    bpm: 90,
    swing: 0.15,
    bitDepth: 12,
    tracks: [kick, snare, hat, openhat, clap, rim, cowbell, tom],
    createdAt: Date.now(),
    updatedAt: Date.now(),
  }
}
