import type { Pattern, Track } from "./types"
import { STEP_COUNT } from "./types"

/* -------------------------------------------------------------------------- */
/*  SP1200-style DSP helpers                                                   */
/* -------------------------------------------------------------------------- */

/**
 * Builds a WaveShaper curve that quantizes the signal to `bits` bit depth.
 * The classic SP-1200 ran at 12-bit, which gives it its gritty character.
 */
export function makeBitcrushCurve(bits: number): Float32Array {
  const n = 2048
  const curve = new Float32Array(n)
  const levels = Math.pow(2, bits)
  for (let i = 0; i < n; i++) {
    const x = (i / (n - 1)) * 2 - 1
    // Quantize to the available levels
    curve[i] = Math.round(x * (levels / 2)) / (levels / 2)
  }
  return curve
}

let noiseBufferCache: { rate: number; buffer: AudioBuffer } | null = null
function getNoiseBuffer(ctx: BaseAudioContext): AudioBuffer {
  if (noiseBufferCache && noiseBufferCache.rate === ctx.sampleRate) {
    return noiseBufferCache.buffer
  }
  const len = Math.floor(ctx.sampleRate * 2)
  const buffer = ctx.createBuffer(1, len, ctx.sampleRate)
  const data = buffer.getChannelData(0)
  for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1
  noiseBufferCache = { rate: ctx.sampleRate, buffer }
  return buffer
}

/* -------------------------------------------------------------------------- */
/*  Sample decoding + caching                                                  */
/* -------------------------------------------------------------------------- */

const sampleBufferCache = new Map<string, AudioBuffer>()

async function dataUrlToArrayBuffer(dataUrl: string): Promise<ArrayBuffer> {
  const res = await fetch(dataUrl)
  return res.arrayBuffer()
}

export async function decodeSample(
  ctx: BaseAudioContext,
  dataUrl: string,
): Promise<AudioBuffer> {
  const cached = sampleBufferCache.get(dataUrl)
  if (cached && cached.sampleRate === ctx.sampleRate) return cached
  const arr = await dataUrlToArrayBuffer(dataUrl)
  // decodeAudioData needs a real AudioContext-compatible decoder; both online
  // and offline contexts support it.
  const decoded = await ctx.decodeAudioData(arr.slice(0))
  sampleBufferCache.set(dataUrl, decoded)
  return decoded
}

export function clearSampleCache(dataUrl?: string) {
  if (dataUrl) sampleBufferCache.delete(dataUrl)
  else sampleBufferCache.clear()
}

/* -------------------------------------------------------------------------- */
/*  Voice synthesis                                                            */
/* -------------------------------------------------------------------------- */

function env(
  param: AudioParam,
  time: number,
  peak: number,
  attack: number,
  decay: number,
) {
  param.cancelScheduledValues(time)
  param.setValueAtTime(0.0001, time)
  param.linearRampToValueAtTime(peak, time + attack)
  param.exponentialRampToValueAtTime(0.0001, time + attack + decay)
}

interface VoiceCtx {
  ctx: BaseAudioContext
  dest: AudioNode
  track: Track
  time: number
  velocity: number
  /** decoded sample buffer if voice === "sample" */
  sampleBuffer?: AudioBuffer
}

export function triggerVoice({
  ctx,
  dest,
  track,
  time,
  velocity,
  sampleBuffer,
}: VoiceCtx) {
  const gain = ctx.createGain()
  const panner = ctx.createStereoPanner()
  panner.pan.setValueAtTime(track.pan, time)
  gain.connect(panner)
  panner.connect(dest)

  const vol = track.volume * velocity
  const pitchRatio = Math.pow(2, track.pitch / 12)
  const decayScale = 0.4 + track.decay * 1.6 // 0.4x .. 2x

  switch (track.voice) {
    case "sample": {
      if (!sampleBuffer) return
      const src = ctx.createBufferSource()
      src.buffer = sampleBuffer
      src.playbackRate.setValueAtTime(pitchRatio, time)
      const dur = sampleBuffer.duration
      const startOff = Math.min(track.start, track.end) * dur
      const endOff = Math.max(track.start, track.end) * dur
      gain.gain.setValueAtTime(vol, time)
      src.connect(gain)
      src.start(time, startOff, Math.max(0.01, endOff - startOff))
      break
    }
    case "kick": {
      const osc = ctx.createOscillator()
      osc.type = "sine"
      const f0 = 150 + track.tone * 120
      osc.frequency.setValueAtTime(f0 * pitchRatio, time)
      osc.frequency.exponentialRampToValueAtTime(
        45 * pitchRatio,
        time + 0.08 * decayScale,
      )
      env(gain.gain, time, vol, 0.002, 0.35 * decayScale)
      osc.connect(gain)
      osc.start(time)
      osc.stop(time + 0.6 * decayScale)
      break
    }
    case "tom": {
      const osc = ctx.createOscillator()
      osc.type = "sine"
      const f0 = 110 + track.tone * 90
      osc.frequency.setValueAtTime(f0 * pitchRatio, time)
      osc.frequency.exponentialRampToValueAtTime(
        f0 * 0.5 * pitchRatio,
        time + 0.18 * decayScale,
      )
      env(gain.gain, time, vol, 0.003, 0.4 * decayScale)
      osc.connect(gain)
      osc.start(time)
      osc.stop(time + 0.7 * decayScale)
      break
    }
    case "snare": {
      // body
      const osc = ctx.createOscillator()
      osc.type = "triangle"
      osc.frequency.setValueAtTime(180 * pitchRatio, time)
      const bodyGain = ctx.createGain()
      env(bodyGain.gain, time, vol * 0.5, 0.002, 0.12 * decayScale)
      osc.connect(bodyGain)
      bodyGain.connect(gain)
      osc.start(time)
      osc.stop(time + 0.3 * decayScale)
      // noise
      const noise = ctx.createBufferSource()
      noise.buffer = getNoiseBuffer(ctx)
      const bp = ctx.createBiquadFilter()
      bp.type = "highpass"
      bp.frequency.value = 1200 + track.tone * 2000
      const nGain = ctx.createGain()
      env(nGain.gain, time, vol, 0.001, 0.18 * decayScale)
      noise.connect(bp)
      bp.connect(nGain)
      nGain.connect(gain)
      noise.start(time)
      noise.stop(time + 0.3 * decayScale)
      gain.gain.setValueAtTime(1, time)
      break
    }
    case "clap": {
      const bursts = [0, 0.01, 0.02, 0.035]
      bursts.forEach((offset, i) => {
        const noise = ctx.createBufferSource()
        noise.buffer = getNoiseBuffer(ctx)
        const bp = ctx.createBiquadFilter()
        bp.type = "bandpass"
        bp.frequency.value = 1000 + track.tone * 800
        bp.Q.value = 1.2
        const g = ctx.createGain()
        const peak = i === bursts.length - 1 ? vol : vol * 0.6
        env(g.gain, time + offset, peak, 0.001, 0.12 * decayScale)
        noise.connect(bp)
        bp.connect(g)
        g.connect(gain)
        noise.start(time + offset)
        noise.stop(time + offset + 0.2 * decayScale)
      })
      gain.gain.setValueAtTime(1, time)
      break
    }
    case "hihat":
    case "openhat": {
      const isOpen = track.voice === "openhat"
      const noise = ctx.createBufferSource()
      noise.buffer = getNoiseBuffer(ctx)
      const hp = ctx.createBiquadFilter()
      hp.type = "highpass"
      hp.frequency.value = 7000 + track.tone * 3000
      const decayT = (isOpen ? 0.35 : 0.05) * decayScale
      env(gain.gain, time, vol * 0.7, 0.001, decayT)
      noise.connect(hp)
      hp.connect(gain)
      noise.start(time)
      noise.stop(time + decayT + 0.1)
      break
    }
    case "rim": {
      const osc = ctx.createOscillator()
      osc.type = "square"
      osc.frequency.setValueAtTime(1700 * pitchRatio, time)
      const bp = ctx.createBiquadFilter()
      bp.type = "bandpass"
      bp.frequency.value = 1700
      bp.Q.value = 6
      env(gain.gain, time, vol, 0.001, 0.05 * decayScale)
      osc.connect(bp)
      bp.connect(gain)
      osc.start(time)
      osc.stop(time + 0.1 * decayScale)
      break
    }
    case "cowbell": {
      const freqs = [560, 845]
      freqs.forEach((f) => {
        const osc = ctx.createOscillator()
        osc.type = "square"
        osc.frequency.setValueAtTime(f * pitchRatio, time)
        osc.connect(gain)
        osc.start(time)
        osc.stop(time + 0.4 * decayScale)
      })
      const bp = ctx.createBiquadFilter()
      bp.type = "bandpass"
      bp.frequency.value = 2640
      bp.Q.value = 2
      env(gain.gain, time, vol * 0.6, 0.002, 0.35 * decayScale)
      break
    }
  }
}

/* -------------------------------------------------------------------------- */
/*  Live playback engine (look-ahead scheduler)                                */
/* -------------------------------------------------------------------------- */

export class AudioEngine {
  ctx: AudioContext | null = null
  private master: GainNode | null = null
  private crusher: WaveShaperNode | null = null
  private analyser: AnalyserNode | null = null
  private pattern: Pattern | null = null
  private isPlaying = false
  private currentStep = 0
  private nextNoteTime = 0
  private lookahead = 25 // ms
  private scheduleAhead = 0.1 // s
  private timer: number | null = null
  private decodedSamples = new Map<string, AudioBuffer>()

  onStep: ((step: number) => void) | null = null

  async ensureContext() {
    if (!this.ctx) {
      this.ctx = new AudioContext()
      this.master = this.ctx.createGain()
      this.master.gain.value = 0.9
      this.crusher = this.ctx.createWaveShaper()
      this.crusher.curve = makeBitcrushCurve(12)
      this.crusher.oversample = "none"
      this.analyser = this.ctx.createAnalyser()
      this.analyser.fftSize = 256
      this.master.connect(this.crusher)
      this.crusher.connect(this.analyser)
      this.analyser.connect(this.ctx.destination)
    }
    if (this.ctx.state === "suspended") await this.ctx.resume()
    return this.ctx
  }

  getAnalyser() {
    return this.analyser
  }

  setBitDepth(bits: number) {
    if (this.crusher) this.crusher.curve = makeBitcrushCurve(bits)
  }

  setMasterVolume(v: number) {
    if (this.master) this.master.gain.value = v
  }

  async setPattern(pattern: Pattern) {
    this.pattern = pattern
    this.setBitDepth(pattern.bitDepth)
    await this.preloadSamples(pattern)
  }

  private async preloadSamples(pattern: Pattern) {
    if (!this.ctx) return
    for (const track of pattern.tracks) {
      if (track.voice === "sample" && track.sampleData) {
        if (!this.decodedSamples.has(track.sampleData)) {
          try {
            let buf = await decodeSample(this.ctx, track.sampleData)
            if (track.reverse) buf = reverseBuffer(this.ctx, buf)
            this.decodedSamples.set(track.sampleData + (track.reverse ? "#r" : ""), buf)
          } catch (e) {
            console.log("[v0] failed to decode sample", e)
          }
        }
      }
    }
  }

  async refreshTrackSample(track: Track) {
    if (!this.ctx || track.voice !== "sample" || !track.sampleData) return
    const key = track.sampleData + (track.reverse ? "#r" : "")
    if (this.decodedSamples.has(key)) return
    try {
      let buf = await decodeSample(this.ctx, track.sampleData)
      if (track.reverse) buf = reverseBuffer(this.ctx, buf)
      this.decodedSamples.set(key, buf)
    } catch (e) {
      console.log("[v0] refresh sample failed", e)
    }
  }

  private secondsPerStep() {
    if (!this.pattern) return 0.125
    const secPerBeat = 60 / this.pattern.bpm
    return secPerBeat / 4 // 16th notes
  }

  private scheduleStep(step: number, time: number) {
    if (!this.pattern || !this.ctx || !this.master) return
    const anySolo = this.pattern.tracks.some((t) => t.solo)
    for (const track of this.pattern.tracks) {
      const vel = track.steps[step]
      if (!vel) continue
      if (track.muted) continue
      if (anySolo && !track.solo) continue
      let sampleBuffer: AudioBuffer | undefined
      if (track.voice === "sample" && track.sampleData) {
        sampleBuffer = this.decodedSamples.get(
          track.sampleData + (track.reverse ? "#r" : ""),
        )
      }
      triggerVoice({
        ctx: this.ctx,
        dest: this.master,
        track,
        time,
        velocity: vel,
        sampleBuffer,
      })
    }
  }

  private scheduler = () => {
    if (!this.ctx || !this.pattern) return
    while (this.nextNoteTime < this.ctx.currentTime + this.scheduleAhead) {
      // swing: delay odd 16ths
      const swingAmount = this.pattern.swing
      const isOffbeat = this.currentStep % 2 === 1
      const swingDelay = isOffbeat
        ? this.secondsPerStep() * 0.5 * swingAmount
        : 0
      this.scheduleStep(this.currentStep, this.nextNoteTime + swingDelay)
      const stepToReport = this.currentStep
      const timeUntil = (this.nextNoteTime - this.ctx.currentTime) * 1000
      window.setTimeout(
        () => this.onStep?.(stepToReport),
        Math.max(0, timeUntil),
      )
      this.nextNoteTime += this.secondsPerStep()
      this.currentStep = (this.currentStep + 1) % STEP_COUNT
    }
    this.timer = window.setTimeout(this.scheduler, this.lookahead)
  }

  async play() {
    await this.ensureContext()
    if (!this.ctx) return
    this.isPlaying = true
    this.currentStep = 0
    this.nextNoteTime = this.ctx.currentTime + 0.05
    this.scheduler()
  }

  stop() {
    this.isPlaying = false
    if (this.timer) window.clearTimeout(this.timer)
    this.timer = null
    this.currentStep = 0
    this.onStep?.(-1)
  }

  playing() {
    return this.isPlaying
  }

  /** Trigger a single voice immediately (for auditioning pads). */
  async audition(track: Track) {
    await this.ensureContext()
    if (!this.ctx || !this.master) return
    let sampleBuffer: AudioBuffer | undefined
    if (track.voice === "sample" && track.sampleData) {
      await this.refreshTrackSample(track)
      sampleBuffer = this.decodedSamples.get(
        track.sampleData + (track.reverse ? "#r" : ""),
      )
    }
    triggerVoice({
      ctx: this.ctx,
      dest: this.master,
      track,
      time: this.ctx.currentTime + 0.01,
      velocity: 1,
      sampleBuffer,
    })
  }

  invalidateSample(dataUrl: string) {
    this.decodedSamples.delete(dataUrl)
    this.decodedSamples.delete(dataUrl + "#r")
    clearSampleCache(dataUrl)
  }
}

export function reverseBuffer(ctx: BaseAudioContext, buffer: AudioBuffer) {
  const rev = ctx.createBuffer(
    buffer.numberOfChannels,
    buffer.length,
    buffer.sampleRate,
  )
  for (let c = 0; c < buffer.numberOfChannels; c++) {
    const src = buffer.getChannelData(c)
    const dst = rev.getChannelData(c)
    for (let i = 0, j = src.length - 1; i < src.length; i++, j--) {
      dst[i] = src[j]
    }
  }
  return rev
}
