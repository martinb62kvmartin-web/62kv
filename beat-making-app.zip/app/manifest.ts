import type { MetadataRoute } from "next"

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "SP-STUDIO — Битмейкер SP1200",
    short_name: "SP-STUDIO",
    description:
      "Битмейкер в стиле SP-1200: секвенсор, редактор сэмплов, экспорт WAV и разделение на стемы.",
    start_url: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#1a1815",
    theme_color: "#1a1815",
    icons: [
      {
        src: "/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  }
}
