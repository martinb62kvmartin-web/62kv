"use client"

import { useState } from "react"
import { Grid3x3, Library, Download, Scissors, Smartphone } from "lucide-react"
import { useStudio } from "@/hooks/use-studio"
import { TransportBar } from "@/components/transport-bar"
import { StepSequencer } from "@/components/step-sequencer"
import { TrackEditor } from "@/components/track-editor"
import { PatternLibrary } from "@/components/pattern-library"
import { ExportPanel } from "@/components/export-panel"
import { StemSplitter } from "@/components/stem-splitter"
import { InstallGuide } from "@/components/install-guide"
import { cn } from "@/lib/utils"

type Tab = "seq" | "library" | "export" | "stems"

const TABS: { id: Tab; label: string; icon: typeof Grid3x3 }[] = [
  { id: "seq", label: "БИТ", icon: Grid3x3 },
  { id: "library", label: "ПАТТЕРНЫ", icon: Library },
  { id: "export", label: "ЭКСПОРТ", icon: Download },
  { id: "stems", label: "СТЕМЫ", icon: Scissors },
]

export default function Page() {
  const studio = useStudio()
  const [tab, setTab] = useState<Tab>("seq")
  const [editTrack, setEditTrack] = useState<string | null>(null)
  const [showInstall, setShowInstall] = useState(false)

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col bg-background pb-20">
      <TransportBar studio={studio} />

      <div className="flex items-center justify-between border-b border-border/60 bg-card/40 px-3 py-1.5">
        <span className="font-mono text-[10px] font-bold tracking-widest text-primary">
          SP-1200 STUDIO
        </span>
        <button
          onClick={() => setShowInstall(true)}
          className="flex items-center gap-1 rounded-md bg-secondary px-2 py-1 font-mono text-[9px] font-semibold text-secondary-foreground transition active:translate-y-px"
        >
          <Smartphone className="size-3" />
          УСТАНОВИТЬ / APK
        </button>
      </div>

      <div className="flex-1">
        {tab === "seq" && (
          <StepSequencer studio={studio} onEditTrack={setEditTrack} />
        )}
        {tab === "library" && <PatternLibrary studio={studio} />}
        {tab === "export" && <ExportPanel studio={studio} />}
        {tab === "stems" && <StemSplitter studio={studio} />}
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 mx-auto flex max-w-2xl items-stretch border-t border-border bg-card/95 backdrop-blur">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            aria-current={tab === id}
            className={cn(
              "flex flex-1 flex-col items-center gap-1 py-2.5 transition",
              tab === id
                ? "text-primary"
                : "text-muted-foreground active:text-foreground",
            )}
          >
            <Icon className="size-5" />
            <span className="font-mono text-[9px] font-semibold tracking-wide">
              {label}
            </span>
          </button>
        ))}
      </nav>

      <TrackEditor
        studio={studio}
        trackId={editTrack}
        onClose={() => setEditTrack(null)}
      />
      <InstallGuide open={showInstall} onClose={() => setShowInstall(false)} />
    </main>
  )
}
